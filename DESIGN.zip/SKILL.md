---
name: AIpacken Design System
description: Brand, color, type, and component kit for AIpacken — a Munich-based pragmatic AI consulting practice. Use whenever producing AIpacken-branded marketing pages, decks, service one-pagers, emails, or internal tools.
---

# AIpacken Design System — Skill

Pragmatic AI consulting brand for the German Mittelstand. Calm, editorial, anti-hype. One brand color (teal `#0e9083`) on white, with soft teal glows as the signature flourish.

## When to use

Invoke this skill for any AIpacken artifact: website pages, service detail pages, workshop decks, proposal one-pagers, client emails, internal Tools screens (Strategy Blueprint, Program Tracker), or social graphics. Don't use it for Convotrail (the consumer mobile app — out of scope here).

## Start here

1. Read `README.md` in this project root — it's the complete brand, content, and visual spec.
2. Import `colors_and_type.css` into any HTML you write — it defines every CSS variable, font, and semantic class the system uses.
3. Check `preview/` for static token cards (colors, type, components, spacing, brand).
4. For full component patterns, read `ui_kits/website/components.jsx` — it has `Navigation`, `Hero`, `ServiceCard`, `GlassCard`, `Badge`, `Button`, `Footer` as reusable React components built on the tokens.

## Non-negotiables

- **One brand color.** Teal `#0e9083`. Gradients stay inside the teal family (`#0e9083 → #1b9b8f` for fills, `#0e9083 → #a0d5d0` for text). Never introduce purple, blue, pink, or multi-hue gradients.
- **Foreground is `#2c3e3a`, not black.** Pure black reads corporate; the warm ink signals editorial.
- **Voice: "we," pragmatic, anti-hype.** Short active sentences. CTAs end with `→`. Hyphens are space-hyphen-space, not em-dash. Never use "leverage," "unlock," "empower."
- **Typography pairing.** Plus Jakarta Sans (display + wordmark, 700/800) · Inter (UI, body) · Lora (longform editorial) · DM Sans (logo subtext only). Headings tracked `-0.02em`.
- **No emoji** in UI. One exception: the footer's `❤` in "Created with ❤".
- **Iconography is Lucide only.** 2px stroke, `currentColor`. 20px default, 24px inside icon tiles, 32px on service-detail hero tiles.
- **Signature surface: `.glass-card`.** 28px radius, 1px teal-tinted border, stacked md shadow + teal glow (`0 0 20px rgba(14,144,131,.15)`). Use for service cards and hero surfaces.
- **Signature status element: `.badge-glow`.** Pill, uppercase 11px label at `0.10em`, pulsing teal dot. The brand's most recognizable capsule.

## Common builds

- **Marketing page** → copy `ui_kits/website/index.html` + `components.jsx` as a starting point; mount `<Hero>`, `<ServicesSection>`, `<Footer>`.
- **Service detail page** → `<ServiceDetail>` pattern: back-link, 64px icon tile, gradient H1, intro paragraph, deliverables list with `<CheckCircle>` bullets.
- **Deck / slide** → white canvas, Plus Jakarta Sans headings at 48–72px, teal text-gradient on key phrases, badge-glow as section eyebrow.
- **Email / letter** → Inter throughout, single teal CTA button with `→` suffix, `#2c3e3a` body, `#5a6b68` for muted lines.

## Known gaps

- Real fonts load from Google CDN (not self-hosted).
- Michael's headshot (`aimike.jpeg`) is not in the repo — use the `assets/portrait-placeholder.svg` and flag the substitution.
- Convotrail mobile UI patterns are out of scope.
