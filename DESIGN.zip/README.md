# AIpacken Design System

> **KI anpacken. Zukunft gestalten.** / *Tackling AI. Shaping the future.*

AIpacken (AI Mike) is a Munich-based AI consulting practice led by Michael Wallner. It helps the German *Mittelstand* — mid-sized companies — turn AI from a buzzword into measurable business outcomes. The brand positions itself as **pragmatic, results-focused, and anti-hype**: "No PowerPoint marathons," "We build it up, and you take it from there," "Strategy without execution is a slide deck."

The design system is a clean, editorial-adjacent, **light-teal** system. It's built on a white canvas, uses deep teal as the single brand color, pairs Plus Jakarta Sans (wordmark/display) with Inter (UI) and Lora (longform), and uses soft glows + glass cards instead of heavy gradients or flashy motion. The overall feeling should be: *calm competence*. Innovative, but grown-up.

---

## Sources

- **Codebase:** [github.com/pespila/ai-mike](https://github.com/pespila/ai-mike) (Vite + React + TypeScript + shadcn-ui + Tailwind).
  Canonical tokens live in `src/index.css` (HSL CSS vars) and `tailwind.config.ts`.
- **Built with:** Lovable.dev project `57c149e2-7c3e-463e-ad30-60921ac215a4`.
- **Production domains:** `ai-mike.ai` (company email domain `mike@ai-mike.ai`), referenced as `aipacken.dev` / `aipacken.com`-style positioning in the app copy.
- **Social:**
  - LinkedIn: <https://www.linkedin.com/in/data-and-ai-mike/>
  - YouTube: <https://www.youtube.com/@data-and-ai-mike>
  - Medium:  <https://medium.com/@wallner.michael>

---

## Products represented

AIpacken is primarily **one marketing + tools web product** with two surfaces:

1. **AIpacken Marketing Website** — public pages: Home, Services (Chief AI Officer, Workshops, Keynotes, Mentoring), Publications, About, Contact. Bilingual (DE/EN) via an in-app language switcher. Hosts the brand story, service pages, and SEO content.

2. **AIpacken Tools** — authenticated suite behind `/tools` for clients:
   - *AI Strategy Blueprint* — 5-pillar framework page
   - *AI Program Tracker* — programs → use cases, with Business Case, Timeline, Stage-Gating, RACI tabs
   - *Template Library* — downloadable PDF templates (Stage-Gating, Buy-Reuse-Build, Timeline, RACI)
   - *Admin panel* — user management

A separate consumer mobile app, **Convotrail**, is linked via legal-only pages (Privacy Policy, Terms) — it lives under the same web brand but is out of scope for UI recreation.

---

## Index / manifest

| File / folder                 | What it is                                                             |
|-------------------------------|------------------------------------------------------------------------|
| `README.md`                   | This file — brand context, fundamentals, iconography                   |
| `SKILL.md`                    | Agent Skill entry point (cross-compatible with Claude Code)            |
| `colors_and_type.css`         | All CSS vars (color + type) and semantic classes. Single source.       |
| `assets/`                     | Logos, icon sets, imagery placeholders                                 |
| `preview/`                    | Small HTML cards registered to the Design System tab                   |
| `ui_kits/website/`            | Marketing site recreation — Home, Services, About, CTA                 |
| `ui_kits/tools/`              | Internal Tools suite — Blueprint, Program Tracker, Templates           |

---

## CONTENT FUNDAMENTALS

The brand voice is the single most defining asset AIpacken has. It's directly oppositional to typical consulting-speak.

### Tone

- **Pragmatic > aspirational.** "AI That Actually Works." "Results, not slide decks." "We make ourselves unnecessary."
- **Anti-hype, explicitly.** Copy routinely calls out what AIpacken is *not*: *"No PowerPoint marathons. No generic playbooks. No death-by-PowerPoint. No hype, no buzzwords."*
- **Confident but grounded.** Claims are backed by numbers ("10+ AI projects", "5 pillars") and sector names (manufacturing, automotive, technology). Never vague.
- **Short sentences. Active voice.** Copy is punchy — "Strategy without execution is a slide deck. Execution without strategy is a cost center." Sentences rarely exceed 20 words.
- **Honest about failure.** *"Most AI projects fail — not because the technology doesn't work, but because strategy is missing."* This is part of the positioning.

### Voice

- **"We," not "I."** Even though it's a one-person practice (Michael Wallner), all public copy uses plural: "We help mid-sized companies…", "We step in as your interim Chief AI Officer." This is intentional and non-negotiable.
- **Directly addresses the reader as "you."** "Your audience wants clarity." "Your business." "Whether you're stepping into your first AI role…"
- **Bilingual with different register.** German copy uses "anpacken" (to tackle, to get stuck in) — a deliberately blue-collar verb. English mirrors this with "tackle," never "leverage" or "unlock."

### Casing

- **Sentence case for buttons & CTAs** with action verbs: "Let's Talk", "Learn More →", "Book a Workshop →", "Start the Conversation".
- **Title Case for navigation and section titles:** "AI Strategy Blueprint", "Chief AI Officer - On Demand".
- **UPPERCASE with 0.10em tracking** only for eyebrow/badge labels (e.g. the pulsing teal badge).
- **Hyphens as em-dashes:** the codebase copy uses " - " (space-hyphen-space), not em-dashes. Preserve this pattern.
- **Arrow suffix for CTAs:** "Learn More →", "Book a Workshop →" — a consistent UI tic.

### Examples (straight from en.json)

> **Hero:** "AI That Actually Works - In Your Business."
> "Most AI projects deliver nothing. Ours deliver results."

> **Keynotes:** "Your audience wants clarity, not buzzwords."

> **About:** "Strategy without execution is a slide deck. Execution without strategy is a cost center."

> **CAIO:** "Our goal is to make ourselves unnecessary - we build it up, and you take it from there."

### Emoji & special chars

- **Emoji:** effectively **never** in UI. One exception: the footer's "Created with ❤" — a single heart, at the end, as a human touch. Do not add emoji to cards, buttons, or marketing copy.
- **Arrows:** `→` as the right-arrow in CTAs (not `>` or `»`).
- **Pulsing dot:** teal `•` glyph rendered as a `<span>` inside `.badge-glow` — the brand's signature live-pulse element.

---

## VISUAL FOUNDATIONS

### Palette

One color does the work: **teal #0e9083**.

- **Background** is almost always `#ffffff`. Section alternates use `#f0f5f4` (pale teal-gray) or `#f8fafa` (near-white warm).
- **Foreground** is **not pure black** — it's `#2c3e3a`, a desaturated ink-teal. This is deliberate: pure black would feel corporate; the warm ink signals editorial warmth.
- **Muted foreground** is `#5a6b68` — same family, lower contrast.
- **Gradients** are short and teal-only: `linear-gradient(135deg, #0e9083 → #1b9b8f)` for fills, and `linear-gradient(135deg, #0e9083 → #a0d5d0)` for the "text-gradient" effect. **Never** use purple, blue, pink, or any multi-hue gradient.
- **Semantic** colors (success/warning/danger) are standard but used *sparingly* and muted.

### Typography

- **Plus Jakarta Sans (700/800/900)** — the logo wordmark and all display headings. Tracking **-0.02em** on headings, line-height 1.15.
- **Inter** — all UI, buttons, body, form elements.
- **Lora** — longform prose / editorial sections (the `.prose` and `.longform` classes). Line-height 1.6.
- **DM Sans (500)** — used specifically for the logo's subtext ("KI anpacken. Zukunft gestalten."). Acts as a small-caps-adjacent secondary voice.
- No monospace display usage outside of inline `<code>`.

### Backgrounds

- **Default:** flat white. The system trusts whitespace.
- **Hero / marquee sections:** `.bg-creative-pattern` — three stacked radial gradients on a 160° linear gradient from white → #f8fafa → #f0f5f4. Extremely subtle; reads as "almost white, with presence."
- **`.creative-glow` overlay:** soft teal radial blooms positioned at 65%/35%, 20%/80%, 75%/80% — `mix-blend-mode: multiply`, low opacity. Creates *barely-there* atmosphere behind hero content.
- **Grid pattern:** available (`.bg-grid-pattern`, 20px cells at 6% opacity) but used rarely — mostly as an accent on technical/tool pages.
- **No hand-drawn illustrations.** No photography-as-background. No textures. No noise/grain. The system is crisp and typographic.

### Animation

- **Easings:** `ease-out` for entries, `ease-in-out` for loops. No bounces, no spring physics, no aggressive cubic-beziers.
- **Durations:** fast (150ms) for hovers, 300ms for color/transform, 500ms for entries.
- **Key loops:** `float` (gentle 10px up-down, 3s), `pulse-teal` (glow badge dot, 2s), `spin-slow` (8s — decorative only), `gradient-shift` (3s on animated gradient fills).
- **Entry:** a single `fade-in` (opacity + 10px translateY) applied to hero elements. That's it.
- **Never:** flashy confetti, scroll-jacking, letter-by-letter reveals, big bouncing numbers.

### Hover states

- **Buttons (primary):** `filter: brightness(1.05)` + `translateY(-2px)`. Gradient stays the same.
- **Buttons (outline):** background fills to the primary gradient; text flips to white.
- **Nav links:** muted-foreground → primary teal, instant.
- **Glass cards:** border strengthens (0.25 → 0.35 opacity teal), shadow deepens, lifts `translateY(-4px)` over 300ms ease.
- **Ghost items:** `hover:bg-accent hover:text-accent-foreground` — subtle tinted fill.

### Press / active states

- **No shrink.** Press states use darker teal (`--primary-pressed: #0a6d63`), not scale-down.
- **Focus-visible** is explicit: 2px ring in `--ring` with 2px offset on `--background`.

### Borders

- **Default border:** `rgba(0, 0, 0, 0.08)` — soft hairline.
- **Primary-tinted border:** `rgba(14, 144, 131, 0.25)` — on glass cards, highlight boxes, badges.
- **Strong primary border:** `rgba(14, 144, 131, 0.35)` — on hover states or emphasis.
- **Border-radius ladder:** 4 / 6 / 8 / 12 / 16 / 28 / 999. The system's signature radius is **28px** on `.glass-card` — noticeably larger than typical shadcn defaults.

### Shadow systems

Three-stop system, always soft:

1. **`--shadow-sm` (1px, 4% black)** — inputs, flat cards.
2. **`--shadow-md` (4px/12px, 10% black)** — default card elevation.
3. **`--shadow-lg` (12px/32px, 12% black)** — hover / modal.

Plus a **signature "teal glow"**: `0 0 20px rgba(14, 144, 131, 0.15)` — stacked with an elevation shadow on `.glass-card` and `.badge-glow`. Use sparingly; it's the brand's one visual flourish.

- **Inset shadows** appear only on `.highlight-box`: `inset 0 1px 0 rgba(14, 144, 131, 0.10)` — a 1px tinted highlight at the top edge.

### Protection / capsules

- **Navigation** uses a translucent capsule: `bg-[rgba(255,255,255,0.9)] backdrop-blur-xl` with a 1px bottom border. Sticky, always on.
- **Badge-glow** is the pill-shaped status capsule: 999px radius, white fill, teal border, uppercase 11px text with 0.10em tracking, + the pulsing dot. This is the **brand's iconic component**.
- Full-bleed color blocks are rare — cards and sections prefer white on white with subtle borders over coloured containers.

### Layout rules

- **Max content width:** `container mx-auto` → effectively 1400px at 2xl; most copy blocks constrain further to `max-w-3xl` (48rem) or `max-w-4xl` (64rem).
- **Horizontal padding:** `px-4` (16px) mobile, scaling up via container.
- **Section rhythm:** `py-20` (80px) default, `py-20 lg:py-32` (128px) on hero. Consistent vertical tempo.
- **Grid:** 1-col mobile → 2-col tablet → 4-col desktop on card grids, 1→2 for service detail pairs, `gap-8` standard.

### Transparency & blur

- **`backdrop-blur-xl`** on the sticky nav (the only place it appears).
- **Low-opacity overlays** on `.creative-glow` (mix-blend-multiply) and `.glass-card::before` (blurred radial blooms, inset -25%, opacity 0.85).
- **Never** frosted-glass-everywhere. Blur is a single-use emphasis tool.

### Imagery vibe

- **Warm, slightly muted.** Professional headshot of Michael (`aimike.jpeg`) is the anchor — ringed with a `ring-2 ring-primary/50` and a soft teal glow.
- **Avatars are circular** (`.aimike`: `border-radius: 50%; aspect-ratio: 1/1`).
- **No stock photography** in the current site. When adding imagery: prefer **warm editorial, muted saturation, slight teal wash** in post. Avoid cold corporate blue, high-key lifestyle, or black-and-white.

### Corner radii recap

| Scale      | Token            | Usage                                    |
|------------|------------------|------------------------------------------|
| 4 px       | `--radius-xs`    | code chips, tight pills                  |
| 6 px       | `--radius-sm`    | small buttons, inputs                    |
| 8 px       | `--radius`       | **default** — buttons, inputs, alerts    |
| 12 px      | `--radius-md`    | icon tiles (service card icon wrappers)  |
| 16 px      | `--radius-lg`    | highlight boxes                          |
| 28 px      | `--radius-xl`    | **glass-card signature**                 |
| 999 px     | `--radius-pill`  | badge-glow, avatar, language toggle      |

### Card anatomy

Two cards dominate the system:

1. **Standard `Card`** — white, 1px border, 8px radius, `shadow-sm`. Used for info blocks (About page education/contact cards).
2. **`.glass-card`** — 28px radius, subtle inner gradient (white → #f8fafa), 1px teal-tinted border, stacked `shadow-md` + teal glow. A pseudo-element radial bloom sits behind the content. On hover: border strengthens, shadow deepens, lifts 4px. Used for service cards on Home + Services pages — the brand's hero surface.

---

## ICONOGRAPHY

AIpacken uses **[Lucide](https://lucide.dev/)** exclusively — imported as a React library (`lucide-react`) in the codebase. No custom icon system, no icon font, no PNG icons. Every glyph in the product is a Lucide SVG.

### Rules

- **Stroke-based, 2px weight** (Lucide default). Never swap to filled variants mid-page.
- **Default size:** 20px (`h-5 w-5`) for nav/inline, 16px (`h-4 w-4`) for tight label rows, 24px (`h-6 w-6`) inside the service-card icon tiles, 32px (`h-8 w-8`) on service-detail hero tiles.
- **Color:** `currentColor` by default → inherits from parent. On primary icon tiles, color is forced to `text-primary-foreground` (white) over the teal gradient background.
- **Icon tile treatment:** Lucide glyph centered in a 48×48 (card) or 64×64 (service detail) rounded square with `bg-gradient-primary` and `rounded-lg` / `rounded-xl`. This is the system's most visible icon pattern.

### Icons actually used in the product

`Briefcase`, `Target`, `Mic`, `UserRound` (service set) — `Wrench` (tools) — `Menu` (mobile nav) — `MapPin`, `Mail`, `Linkedin`, `GraduationCap` (about) — `Youtube` (footer) — `ArrowLeft`, `ArrowRight` (nav/CTAs) — `CheckCircle` (deliverable lists) — plus the shadcn-ui set inside UI primitives.

### Delivery in THIS design system

- We **do not bundle Lucide** as files in `assets/`. Instead, UI kits load it from CDN via the ESM build to stay zero-copy:
  ```html
  <!-- Lucide via CDN (stroke = 2, 24px default) -->
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
  <script>lucide.createIcons();</script>
  ```
- For static HTML cards in `preview/`, inline the specific SVG glyphs as needed (copy from <https://lucide.dev/icons/>) — always `stroke="currentColor" stroke-width="2" fill="none"`.

### Emoji & unicode

- **Emoji:** not used in UI. Only the footer's `❤` in "Created with ❤". Flag it if you see others creeping in.
- **Unicode-as-icon:** one character in regular use — `→` (U+2192) at the end of CTA labels. Do **not** substitute with Lucide `ArrowRight` for button text — the character is part of the copy style.
- **Bullet dots:** the pulsing teal dot in `.badge-glow` is a styled `<span>`, not a glyph.

### Logos & marks

- **Wordmark:** a two-color lockup built in SVG inside `src/components/Logo.tsx`. "AI" fills with teal (#0e9083 → 1b9b8f gradient), "packen" fills with ink (#2c3e3a). Subtext below in DM Sans 500.
- **No monogram / no icon mark.** The only brand mark is the full wordmark. Favicon in the repo (`favicon.png`) is treated as the single icon representation; we re-create the wordmark in SVG as the canonical asset (`assets/logo.svg`).

---

## Known gaps / substitutions

- **Fonts:** all four families (Plus Jakarta Sans, Inter, Lora, DM Sans) are loaded via Google Fonts CDN inside `colors_and_type.css`. No local `.ttf`/`.woff2` in `fonts/`. If the team wants offline/self-hosted fonts, please provide files or approve this CDN approach.
- **Imagery:** the repo references `/lovable-uploads/aimike.jpeg` (Michael's headshot) — not accessible via the GitHub import. We use a neutral avatar placeholder in UI kits and flag this. Please upload the real portrait + any secondary imagery.
- **Convotrail mobile UI:** out of scope for this system — only legal pages exist in code. Ask if the iOS app needs its own kit later.
