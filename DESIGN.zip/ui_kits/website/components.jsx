/* global React */
const { useState } = React;

function Icon({ name, size = 20, stroke = 2, style }) {
  const s = { width: size, height: size, stroke: 'currentColor', strokeWidth: stroke, fill: 'none', strokeLinecap: 'round', strokeLinejoin: 'round', ...style };
  const map = {
    briefcase: <svg {...s} viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>,
    target: <svg {...s} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>,
    mic: <svg {...s} viewBox="0 0 24 24"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>,
    user: <svg {...s} viewBox="0 0 24 24"><circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/></svg>,
    wrench: <svg {...s} viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>,
    check: <svg {...s} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="9 12 11 14 15 10"/></svg>,
    arrowLeft: <svg {...s} viewBox="0 0 24 24"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>,
    menu: <svg {...s} viewBox="0 0 24 24"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>,
    mail: <svg {...s} viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="16" rx="2"/><polyline points="22,6 12,13 2,6"/></svg>,
    pin: <svg {...s} viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>,
    linkedin: <svg {...s} viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>,
    youtube: <svg {...s} viewBox="0 0 24 24"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" fill="currentColor"/></svg>,
    globe: <svg {...s} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>,
  };
  return map[name] || null;
}

function Logo({ size = 'md', locale = 'de' }) {
  const sizes = { sm: 28, md: 36, lg: 52, xl: 72 };
  const fs = sizes[size];
  const sub = locale === 'en' ? 'Tackling AI. Shaping the future.' : 'KI anpacken. Zukunft gestalten.';
  return (
    <div style={{ display: 'inline-flex', flexDirection: 'column' }}>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: fs, letterSpacing: '-0.02em', lineHeight: 1, color: '#2c3e3a' }}>
        <span style={{ background: 'linear-gradient(135deg,#0e9083,#1b9b8f)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>AI</span>packen
      </div>
      {size !== 'sm' && (
        <div style={{ fontFamily: 'var(--font-subtext)', fontWeight: 500, fontSize: Math.max(11, fs * 0.22), color: '#5a6b68', letterSpacing: '0.02em', marginTop: 4 }}>{sub}</div>
      )}
    </div>
  );
}

function Button({ variant = 'primary', size = 'md', children, onClick, style }) {
  const base = { display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 8, fontFamily: 'var(--font-sans)', fontWeight: 600, cursor: 'pointer', border: 'none', transition: 'all .2s var(--ease-out)', whiteSpace: 'nowrap' };
  const sizes = { sm: { padding: '8px 14px', fontSize: 13 }, md: { padding: '10px 20px', fontSize: 14 }, lg: { padding: '14px 32px', fontSize: 16 } };
  const variants = {
    primary: { background: 'linear-gradient(135deg,#0e9083,#1b9b8f)', color: '#fff' },
    outline: { background: '#fff', color: '#2c3e3a', border: '1px solid rgba(14,144,131,.3)', fontWeight: 500 },
    ghost: { background: 'transparent', color: '#5a6b68', fontWeight: 500 },
  };
  return <button onClick={onClick} style={{ ...base, ...sizes[size], ...variants[variant], ...style }}>{children}</button>;
}

function Badge({ children, variant = 'glow' }) {
  if (variant === 'glow') {
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, padding: '6px 15px', borderRadius: 999, fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.10em', background: '#fff', border: '1px solid rgba(14,144,131,.35)', color: '#0e9083', boxShadow: '0 0 20px rgba(14,144,131,.15)' }}>
        <span style={{ width: 8, height: 8, borderRadius: 999, background: '#0e9083', boxShadow: '0 0 12px rgba(14,144,131,.95),0 0 24px rgba(14,144,131,.45)', animation: 'pulse-teal 2s ease-in-out infinite' }} />
        {children}
      </span>
    );
  }
  return <span style={{ display: 'inline-flex', padding: '4px 12px', borderRadius: 999, fontSize: 12, fontWeight: 500, background: '#f0f5f4', color: '#0a6d63', border: '1px solid rgba(14,144,131,.25)' }}>{children}</span>;
}

function Navigation({ active = 'home', lang = 'en', onLang, onNav }) {
  const items = [
    { k: 'home', l: lang === 'de' ? 'Home' : 'Home' },
    { k: 'services', l: lang === 'de' ? 'Services' : 'Services' },
    { k: 'publications', l: lang === 'de' ? 'Publikationen' : 'Publications' },
    { k: 'about', l: lang === 'de' ? 'Über uns' : 'About Us' },
    { k: 'contact', l: lang === 'de' ? 'Kontakt' : 'Contact' },
  ];
  return (
    <header style={{ position: 'sticky', top: 0, zIndex: 50, width: '100%', borderBottom: '1px solid rgba(0,0,0,.08)', background: 'rgba(255,255,255,.9)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', display: 'flex', height: 64, alignItems: 'center', justifyContent: 'space-between' }}>
        <a href="#" onClick={e => { e.preventDefault(); onNav && onNav('home'); }} style={{ textDecoration: 'none' }}><Logo size="sm" locale={lang} /></a>
        <nav style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
          {items.map(i => (
            <a key={i.k} href="#" onClick={e => { e.preventDefault(); onNav && onNav(i.k); }}
               style={{ fontSize: 13.5, fontWeight: 500, color: active === i.k ? '#0e9083' : '#5a6b68', textDecoration: 'none', borderBottom: active === i.k ? '2px solid #0e9083' : '2px solid transparent', paddingBottom: 3, transition: 'color .15s' }}>{i.l}</a>
          ))}
          <button onClick={() => onNav && onNav('tools')} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'transparent', border: 'none', fontSize: 13.5, fontWeight: 500, color: active === 'tools' ? '#0e9083' : '#5a6b68', cursor: 'pointer' }}>
            <Icon name="wrench" size={16} /> {lang === 'de' ? 'Tools' : 'Tools'}
          </button>
        </nav>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button onClick={() => onLang && onLang(lang === 'de' ? 'en' : 'de')} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 12px', borderRadius: 999, border: '1px solid rgba(0,0,0,.08)', background: '#fff', cursor: 'pointer', fontSize: 12, fontWeight: 600, color: '#2c3e3a', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            <Icon name="globe" size={14} style={{ stroke: '#0e9083' }} /> {lang === 'de' ? 'DE' : 'EN'}
          </button>
        </div>
      </div>
    </header>
  );
}

function GlassCard({ children, style }) {
  return (
    <div style={{ position: 'relative', borderRadius: 28, background: 'linear-gradient(150deg,rgba(255,255,255,.98),rgba(248,250,250,.96))', border: '1px solid rgba(14,144,131,.25)', boxShadow: '0 4px 12px rgba(0,0,0,.1),0 0 20px rgba(14,144,131,.1)', overflow: 'hidden', padding: 28, transition: 'all .3s var(--ease-out)', ...style }}>
      <div style={{ position: 'absolute', inset: '-25%', background: 'radial-gradient(circle at top right,rgba(14,144,131,.06),transparent 50%),radial-gradient(circle at bottom left,rgba(160,213,208,.08),transparent 48%)', filter: 'blur(40px)', pointerEvents: 'none' }} />
      <div style={{ position: 'relative' }}>{children}</div>
    </div>
  );
}

function IconTile({ name, size = 48 }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size >= 60 ? 16 : 12, background: 'linear-gradient(135deg,#0e9083,#1b9b8f)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>
      <Icon name={name} size={Math.round(size * 0.5)} />
    </div>
  );
}

function ServiceCard({ icon, title, desc, cta, onClick }) {
  return (
    <GlassCard style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <IconTile name={icon} />
      <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 20, letterSpacing: '-0.02em', margin: '18px 0 10px', background: 'linear-gradient(135deg,#0e9083,#a0d5d0)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', lineHeight: 1.2 }}>{title}</h3>
      <p style={{ fontSize: 14, lineHeight: 1.55, color: '#5a6b68', margin: 0, flex: 1 }}>{desc}</p>
      <div style={{ marginTop: 20 }}><Button variant="outline" onClick={onClick} style={{ width: '100%' }}>{cta}</Button></div>
    </GlassCard>
  );
}

function Hero({ lang = 'en', onCTA }) {
  const title = lang === 'de' ? 'KI, die wirklich funktioniert.' : 'AI That Actually Works.';
  const sub = lang === 'de'
    ? 'Die meisten KI-Projekte liefern nichts. Unsere liefern Ergebnisse. Wir helfen mittelständischen Unternehmen, die richtigen Use Cases zu finden — pragmatisch und ohne Berater-Overhead.'
    : 'Most AI projects deliver nothing. Ours deliver results. We help mid-sized companies find the right AI use cases, build internal capabilities, and turn technology into measurable business outcomes — pragmatic, hands-on, and without the consultant overhead.';
  const cta = lang === 'de' ? 'Sprechen wir' : "Let's Talk";
  return (
    <section style={{ position: 'relative', padding: '96px 24px 120px', background: 'radial-gradient(circle at top right,rgba(14,144,131,.06),transparent 60%),radial-gradient(circle at bottom left,rgba(160,213,208,.05),transparent 55%),linear-gradient(160deg,#ffffff 0%,#f8fafa 50%,#f0f5f4 100%)', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 65% 35%,rgba(14,144,131,.05) 35%,transparent 60%),radial-gradient(circle at 20% 80%,rgba(160,213,208,.06) 22%,transparent 65%),radial-gradient(circle at 75% 80%,rgba(14,144,131,.04) 20%,transparent 72%)', mixBlendMode: 'multiply', pointerEvents: 'none' }} />
      <div style={{ maxWidth: 880, margin: '0 auto', textAlign: 'center', position: 'relative' }}>
        <div style={{ display: 'inline-block', marginBottom: 22 }}><Badge>{lang === 'de' ? 'Jetzt Q2 Engagements buchen' : 'Now booking Q2 engagements'}</Badge></div>
        <div style={{ marginBottom: 18 }}><Logo size="xl" locale={lang} /></div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 'clamp(36px, 5vw, 56px)', letterSpacing: '-0.02em', lineHeight: 1.1, margin: '0 0 20px', color: '#2c3e3a' }}>{title}</h1>
        <p style={{ fontSize: 18, lineHeight: 1.6, color: '#5a6b68', maxWidth: 680, margin: '0 auto 32px' }}>{sub}</p>
        <Button size="lg" onClick={onCTA}>{cta}</Button>
      </div>
    </section>
  );
}

function ServicesSection({ lang = 'en', onPick }) {
  const items = lang === 'de' ? [
    { k: 'caio', icon: 'briefcase', t: 'Chief AI Officer — On Demand', d: 'Sie brauchen KI-Führung, aber keinen Vollzeit-Executive? Wir springen ein — bis Ihre Organisation eigenständig läuft.' },
    { k: 'workshops', icon: 'target', t: 'KI-Workshops — Von der Idee zum Plan', d: 'Keine PowerPoint-Marathons. In praktischen Workshops identifizieren wir die Use Cases, die wirklich Sinn ergeben.' },
    { k: 'keynotes', icon: 'mic', t: 'Keynotes — KI ohne Hype', d: 'Ihr Publikum will Klarheit, keine Buzzwords. Wir übersetzen komplexe KI-Themen in praktische Erkenntnisse.' },
    { k: 'mentoring', icon: 'user', t: 'Mentoring für KI-Führungskräfte', d: 'Ob erste KI-Rolle oder Executive mit neuem Verantwortungsbereich — wir liefern 1:1-Begleitung.' },
  ] : [
    { k: 'caio', icon: 'briefcase', t: 'Chief AI Officer — On Demand', d: 'You need AI leadership but not a full-time executive? We step in until your organization runs independently.' },
    { k: 'workshops', icon: 'target', t: 'AI Workshops — From Idea to Action Plan', d: 'No PowerPoint marathons. In hands-on workshops, we identify the AI use cases that actually make sense.' },
    { k: 'keynotes', icon: 'mic', t: 'Keynotes — AI Without the Hype', d: 'Your audience wants clarity, not buzzwords. We translate complex AI topics into practical insights.' },
    { k: 'mentoring', icon: 'user', t: 'Mentoring for Future AI Leaders', d: 'Whether stepping into your first AI role or building AI fluency as an executive — we provide one-on-one guidance.' },
  ];
  return (
    <section style={{ padding: '96px 24px', background: '#fff' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 28 }}>
          {items.map(i => (
            <ServiceCard key={i.k} icon={i.icon} title={i.t} desc={i.d} cta={lang === 'de' ? 'Mehr erfahren →' : 'Learn More →'} onClick={() => onPick && onPick(i.k)} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ServiceDetail({ which, lang = 'en', onBack }) {
  const data = {
    workshops: {
      icon: 'target',
      title: lang === 'de' ? 'KI-Workshops — Von der Idee zum Plan' : 'AI Workshops — From Idea to Action Plan',
      intro: lang === 'de' ? 'Workshops, die Aktionspläne liefern, keine Foliensätze.' : 'Workshops that deliver action plans, not slide decks.',
      desc: lang === 'de' ? 'In praktischen, interaktiven Sessions arbeiten wir mit Ihrem Leadership-Team, um die KI-Use-Cases zu identifizieren, die wirklich zählen. Keine generischen Playbooks. Keine Folienschlacht.' : 'In practical, hands-on sessions, we work with your leadership team to identify the AI use cases that actually matter for your business. No generic playbooks. No death-by-PowerPoint.',
      deliverables: lang === 'de' ? [
        'Priorisierte KI-Use-Cases nach Geschäftswert und Machbarkeit',
        'Eine konkrete KI-Roadmap, verankert in Ihren strategischen Zielen',
        'Klare nächste Schritte — von der Idee zur Umsetzung',
      ] : [
        'Prioritized AI use cases ranked by business value and feasibility',
        'A concrete AI roadmap tied to your strategic goals',
        'Clear next steps — from idea to implementation',
      ],
    },
  };
  const d = data[which] || data.workshops;
  return (
    <section style={{ position: 'relative', padding: '80px 24px 96px', background: 'linear-gradient(160deg,#ffffff 0%,#f8fafa 50%,#f0f5f4 100%)' }}>
      <div style={{ maxWidth: 720, margin: '0 auto' }}>
        <button onClick={onBack} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, color: '#5a6b68', background: 'transparent', border: 'none', cursor: 'pointer', fontSize: 14, marginBottom: 28, fontFamily: 'var(--font-sans)' }}>
          <Icon name="arrowLeft" size={16} /> {lang === 'de' ? 'Zurück zu Services' : 'Back to Services'}
        </button>
        <IconTile name={d.icon} size={64} />
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 44, letterSpacing: '-0.02em', margin: '24px 0 18px', background: 'linear-gradient(135deg,#0e9083,#a0d5d0)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', lineHeight: 1.1 }}>{d.title}</h1>
        <p style={{ fontSize: 20, fontWeight: 500, color: '#2c3e3a', margin: '0 0 12px' }}>{d.intro}</p>
        <p style={{ fontSize: 16, lineHeight: 1.65, color: '#5a6b68', margin: '0 0 36px' }}>{d.desc}</p>
        <div style={{ background: 'rgba(255,255,255,.8)', backdropFilter: 'blur(8px)', borderRadius: 16, padding: 32, border: '1px solid rgba(14,144,131,.2)', marginBottom: 32 }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 22, letterSpacing: '-0.015em', margin: '0 0 20px', color: '#2c3e3a' }}>{lang === 'de' ? 'Was Sie mitnehmen' : 'What You Walk Away With'}</h2>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {d.deliverables.map((x, i) => (
              <li key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <span style={{ color: '#0e9083', marginTop: 2, flexShrink: 0 }}><Icon name="check" size={20} /></span>
                <span style={{ fontSize: 15, color: '#5a6b68', lineHeight: 1.55 }}>{x}</span>
              </li>
            ))}
          </ul>
        </div>
        <Button size="lg">{lang === 'de' ? 'Workshop buchen' : 'Book a Workshop'}</Button>
      </div>
    </section>
  );
}

function Footer({ lang = 'en' }) {
  return (
    <footer style={{ background: 'rgba(240,245,244,.5)', borderTop: '1px solid rgba(0,0,0,.08)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '48px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 40 }}>
          <div>
            <Logo size="md" locale={lang} />
            <p style={{ fontSize: 13, color: '#5a6b68', maxWidth: 360, marginTop: 14, lineHeight: 1.55 }}>
              {lang === 'de' ? 'Pragmatische KI-Beratung für den Mittelstand — von der Strategie bis zur Umsetzung.' : 'Pragmatic AI consulting for mid-sized companies — from strategy to implementation.'}
            </p>
          </div>
          <div>
            <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 600, margin: '0 0 14px', color: '#2c3e3a' }}>Legal</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <a href="#" style={{ fontSize: 13, color: '#5a6b68' }}>{lang === 'de' ? 'Cookie-Richtlinie' : 'Cookie Policy'}</a>
              <a href="#" style={{ fontSize: 13, color: '#5a6b68' }}>{lang === 'de' ? 'Impressum' : 'Legal Notice'}</a>
              <a href="#" style={{ fontSize: 13, color: '#5a6b68' }}>Convotrail App</a>
            </div>
          </div>
          <div>
            <h4 style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 600, margin: '0 0 14px', color: '#2c3e3a' }}>Connect</h4>
            <div style={{ display: 'flex', gap: 14 }}>
              <a href="#" style={{ color: '#5a6b68' }}><Icon name="linkedin" size={20} /></a>
              <a href="#" style={{ color: '#5a6b68', fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, textDecoration: 'none' }}>M</a>
              <a href="#" style={{ color: '#5a6b68' }}><Icon name="youtube" size={20} /></a>
            </div>
          </div>
        </div>
        <div style={{ borderTop: '1px solid rgba(0,0,0,.08)', marginTop: 40, paddingTop: 24, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <p style={{ fontSize: 13, color: '#5a6b68', margin: 0 }}>© 2026 AIpacken. {lang === 'de' ? 'Alle Rechte vorbehalten.' : 'All rights reserved.'}</p>
          <p style={{ fontSize: 13, color: '#5a6b68', margin: 0 }}>Created with ❤</p>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { Icon, Logo, Button, Badge, Navigation, GlassCard, IconTile, ServiceCard, Hero, ServicesSection, ServiceDetail, Footer });
