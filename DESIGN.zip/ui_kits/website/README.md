# AIpacken Marketing Website — UI Kit

Recreation of the public-facing marketing site: sticky nav, hero with wordmark, service cards (glass-card pattern), service detail with deliverables list, about section, footer.

## Components
- `Navigation.jsx` — sticky translucent header + language switcher + mobile sheet trigger
- `Hero.jsx` — centered wordmark, subtitle, primary gradient CTA
- `ServiceCard.jsx` — glass-card with icon tile, gradient title, description, outline button
- `ServiceDetail.jsx` — back-link, icon tile, gradient heading, deliverables with CheckCircle
- `Footer.jsx` — muted footer with legal links + social
- `Badge.jsx` — pulsing glow badge (shared)
- `Button.jsx` — primary/outline/ghost/link variants (shared)

Reference: `src/pages/Home.tsx`, `Services.tsx`, `services/Workshops.tsx`, `About.tsx`, `components/Navigation.tsx`, `Footer.tsx`.
